a = [[9,1],[8,2],[7,3],[6,4]]
# a = [(9,1),(8,2),(7,3),(6,4)]

print(a)
print(a[0][0])
print(a[0][1])
# a[1][1]=5
# print(type(b))
b=list(a)
# print(type(b))
# print(b)
# print(b[1][1])
b[0][0]=5
print(b)